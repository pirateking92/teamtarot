import{a as t}from"../chunks/entry.WE1SeAUf.js";export{t as start};
