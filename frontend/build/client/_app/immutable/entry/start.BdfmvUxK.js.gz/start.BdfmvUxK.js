import{a as t}from"../chunks/entry.Bl8abHs4.js";export{t as start};
